/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author DELL
 */
public class RegisterBeanTest {

    public RegisterBeanTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getDob method, of class RegisterBean.
     */
    @Test
    public void testGetDob() {
        System.out.println("getDob");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getDob();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDob method, of class RegisterBean.
     */
    @Test
    public void testSetDob() {
        System.out.println("setDob");
        String dob = "";
        RegisterBean instance = new RegisterBean();
        instance.setDob(dob);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFname method, of class RegisterBean.
     */
    @Test
    public void testGetFname() {
        System.out.println("getFname");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getFname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFname method, of class RegisterBean.
     */
    @Test
    public void testSetFname() {
        System.out.println("setFname");
        String fname = "";
        RegisterBean instance = new RegisterBean();
        instance.setFname(fname);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getGender method, of class RegisterBean.
     */
    @Test
    public void testGetGender() {
        System.out.println("getGender");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getGender();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setGender method, of class RegisterBean.
     */
    @Test
    public void testSetGender() {
        System.out.println("setGender");
        String gender = "";
        RegisterBean instance = new RegisterBean();
        instance.setGender(gender);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLname method, of class RegisterBean.
     */
    @Test
    public void testGetLname() {
        System.out.println("getLname");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getLname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLname method, of class RegisterBean.
     */
    @Test
    public void testSetLname() {
        System.out.println("setLname");
        String lname = "";
        RegisterBean instance = new RegisterBean();
        instance.setLname(lname);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPassword method, of class RegisterBean.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPassword method, of class RegisterBean.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "";
        RegisterBean instance = new RegisterBean();
        instance.setPassword(password);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSA method, of class RegisterBean.
     */
    @Test
    public void testGetSA() {
        System.out.println("getSA");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getSA();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSA method, of class RegisterBean.
     */
    @Test
    public void testSetSA() {
        System.out.println("setSA");
        String sA = "";
        RegisterBean instance = new RegisterBean();
        instance.setSA(sA);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSQ method, of class RegisterBean.
     */
    @Test
    public void testGetSQ() {
        System.out.println("getSQ");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getSQ();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSQ method, of class RegisterBean.
     */
    @Test
    public void testSetSQ() {
        System.out.println("setSQ");
        String sQ = "";
        RegisterBean instance = new RegisterBean();
        instance.setSQ(sQ);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getUsername method, of class RegisterBean.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        RegisterBean instance = new RegisterBean();
        String expResult = "";
        String result = instance.getUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setUsername method, of class RegisterBean.
     */
    @Test
    public void testSetUsername() {
        System.out.println("setUsername");
        String username = "";
        RegisterBean instance = new RegisterBean();
        instance.setUsername(username);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validate method, of class RegisterBean.
     */
    @Test
    public void testValidate() {
        System.out.println("validate");
        RegisterBean instance = new RegisterBean();
        int expResult = 0;
        int result = instance.validate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}